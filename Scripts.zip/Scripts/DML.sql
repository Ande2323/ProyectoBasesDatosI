-- =====================================================================
-- Proyecto Final - Bases de Datos 1 - Universidad El Bosque
-- Script 02: DML (inserción de registros de prueba)
-- Ejecutar DESPUÉS de 01_ddl.sql
-- Nota: los hashes SHA2 son solo para pruebas; la app web real debe usar
--       bcrypt/argon2 antes de guardar contraseñas.
-- =====================================================================

USE magic_cards;

-- ---------------------------------------------------------------------
-- Catálogos
-- ---------------------------------------------------------------------
INSERT INTO rol (codigo_rol, nombre) VALUES
  ('ADM', 'Administrador'),
  ('EMP', 'Empleado'),
  ('CLI', 'Cliente');

INSERT INTO idioma (id_idioma, nombre, codigo) VALUES
  (1, 'Inglés',   'EN'),
  (2, 'Español',  'ES'),
  (3, 'Japonés',  'JA');

INSERT INTO rareza (id_rareza, nombre, codigo) VALUES
  (1, 'Común',      'C'),
  (2, 'Infrecuente','U'),
  (3, 'Rara',       'R'),
  (4, 'Mítica',     'M');

INSERT INTO artista (id_artista, nombre) VALUES
  (1, 'Christopher Rush'),
  (2, 'Douglas Shuler'),
  (3, 'Mark Poole'),
  (4, 'Kev Walker'),
  (5, 'Dan Frazier');

INSERT INTO edicion (id_edicion, nombre, codigo_impreso, fecha_lanzamiento, tipo_edicion, cantidad_cartas) VALUES
  (1, 'Limited Edition Alpha', 'LEA', '1993-08-05', 'Core',      295),
  (2, 'Fourth Edition',        '4ED', '1995-04-01', 'Core',      378),
  (3, 'Magic 2010',            'M10', '2009-07-17', 'Core',      249),
  (4, 'Kaladesh',              'KLD', '2016-09-30', 'Expansión', 264);

INSERT INTO condicion (codigo_condicion, nombre, factor_ajuste) VALUES
  ('NM',  'Near Mint',          1.000),
  ('LP',  'Lightly Played',     0.900),
  ('MP',  'Moderately Played',  0.750),
  ('HP',  'Heavily Played',     0.500),
  ('DMG', 'Damaged',            0.250);

INSERT INTO color (id_color, nombre_color, orden_canonico) VALUES
  (1, 'Blanco', 1),
  (2, 'Azul',   2),
  (3, 'Negro',  3),
  (4, 'Rojo',   4),
  (5, 'Verde',  5);

INSERT INTO tipo (id_tipo, nivel, codigo, nombre) VALUES
  (1, 2, 'INS', 'Instantáneo'),
  (2, 2, 'CRE', 'Criatura'),
  (3, 2, 'ART', 'Artefacto'),
  (4, 2, 'PLN', 'Planeswalker'),
  (5, 3, 'ELF', 'Elfo'),
  (6, 3, 'ANG', 'Ángel'),
  (7, 3, 'AVE', 'Ave'),
  (8, 1, 'LEG', 'Legendario');

-- ---------------------------------------------------------------------
-- Cartas y relaciones N:M
-- ---------------------------------------------------------------------
INSERT INTO carta (id_carta, nombre_oficial, texto_oraculo, coste_mana, poder, lealtad, resistencia) VALUES
  (1, 'Lightning Bolt',  'Lightning Bolt deals 3 damage to any target.', '{R}', NULL, NULL, NULL),
  (2, 'Llanowar Elves',  '{T}: Add {G}.',                                  '{G}', '1',  NULL, '1'),
  (3, 'Serra Angel',     'Flying, vigilance',                              '{3}{W}{W}', '4', NULL, '4'),
  (4, 'Counterspell',    'Counter target spell.',                          '{U}{U}', NULL, NULL, NULL),
  (5, 'Sol Ring',        '{T}: Add {C}{C}.',                               '{1}', NULL, NULL, NULL),
  (6, 'Birds of Paradise','Flying. {T}: Add one mana of any color.',       '{G}', '0',  NULL, '1'),
  (7, 'Chandra, Torch of Defiance', 'Planeswalker de Kaladesh.',           '{2}{R}{R}', NULL, '4', NULL);

INSERT INTO carta_color (carta_id_carta, color_id_color) VALUES
  (1, 4), (2, 5), (3, 1), (4, 2), (6, 5), (7, 4);   -- Sol Ring (5) es incolora

INSERT INTO carta_tipo (carta_id_carta, tipo_id_tipo) VALUES
  (1, 1),
  (2, 2), (2, 5),
  (3, 2), (3, 6),
  (4, 1),
  (5, 3),
  (6, 2), (6, 7),
  (7, 4), (7, 8);

-- ---------------------------------------------------------------------
-- Impresiones (las que referencian a otra se insertan después de ella)
-- ---------------------------------------------------------------------
INSERT INTO impresion
  (carta_id_carta, numero_impresion, numero_coleccion, indicador_foil,
   rareza_id_rareza, idioma_id_idioma, artista_id_artista, edicion_id_edicion,
   impresion_carta_id_carta, impresion_numero_impresion) VALUES
  (1, 1, '161', 'N', 1, 1, 1, 1, NULL, NULL),
  (2, 1, '172', 'N', 1, 1, 2, 2, NULL, NULL),
  (3, 1, '36',  'N', 2, 1, 2, 1, NULL, NULL),
  (4, 1, '54',  'N', 2, 1, 3, 1, NULL, NULL),
  (5, 1, '261', 'N', 2, 1, 5, 1, NULL, NULL),
  (6, 1, '189', 'N', 3, 1, 1, 1, NULL, NULL),
  (7, 1, '90',  'N', 4, 1, 4, 4, NULL, NULL);

INSERT INTO impresion
  (carta_id_carta, numero_impresion, numero_coleccion, indicador_foil,
   rareza_id_rareza, idioma_id_idioma, artista_id_artista, edicion_id_edicion,
   impresion_carta_id_carta, impresion_numero_impresion) VALUES
  (1, 2, '146', 'N', 1, 1, 1, 3, 1, 1),   -- reimpresión M10 de la Alpha
  (1, 3, '146', 'S', 1, 2, 1, 3, 1, 1),   -- M10 foil en español
  (3, 2, '33',  'N', 2, 2, 2, 2, 3, 1);   -- Serra Angel 4ED en español

-- ---------------------------------------------------------------------
-- Precios de referencia
-- ---------------------------------------------------------------------
INSERT INTO precio_referencia
  (impresion_carta_id_carta, impresion_numero_impresion, fecha, valor, fuente_cotizacion) VALUES
  (1, 1, '2026-09-01', 480000.00, 'TCGplayer'),
  (1, 1, '2026-10-01', 450000.00, 'TCGplayer'),
  (1, 2, '2026-10-01',  12000.00, 'Cardmarket'),
  (3, 1, '2026-10-01',  95000.00, 'TCGplayer'),
  (5, 1, '2026-10-01', 800000.00, 'TCGplayer'),
  (6, 1, '2026-10-01', 210000.00, 'Cardmarket'),
  (7, 1, '2026-10-01',  70000.00, 'Cardmarket');

-- ---------------------------------------------------------------------
-- Cuentas, empleados y clientes
-- ---------------------------------------------------------------------
INSERT INTO cuenta_usuario (id_cuenta_u, nombre_usuario, contrasena, estado, fecha_u_acceso, rol_codigo_rol) VALUES
  (1, 'lgomez',    SHA2('Admin123*', 256), 'ACTIVA', '2026-10-30 09:15:00', 'ADM'),
  (2, 'arojas',    SHA2('Emp123*',   256), 'ACTIVA', '2026-10-29 14:02:00', 'EMP'),
  (3, 'ctorres',   SHA2('Cli123*',   256), 'ACTIVA', '2026-10-28 18:40:00', 'CLI'),
  (4, 'jperez',    SHA2('Cli123*',   256), 'ACTIVA', NULL,                  'CLI'),
  (5, 'smartinez', SHA2('Cli123*',   256), 'ACTIVA', '2026-10-25 11:00:00', 'CLI');

INSERT INTO empleado
  (tipo_documento, numero_documento, nombres, apellidos, cargo, estado, fecha_vinculacion, cuenta_usuario_id_cuenta_u) VALUES
  ('CC', '1010101010', 'Laura',  'Gómez', 'Administradora', 'ACTIVO', '2024-02-01', 1),
  ('CC', '1020202020', 'Andrés', 'Rojas', 'Vendedor',       'ACTIVO', '2025-06-15', 2);

INSERT INTO cliente
  (tipo_documento, numero_documento, nombres, apellidos, cuenta_usuario_id_cuenta_u) VALUES
  ('CC', '80123456',   'Camila', 'Torres',   3),
  ('CC', '1030303030', 'Juan',   'Pérez',    4),
  ('CE', '99887766',   'Sofía',  'Martínez', 5);

-- ---------------------------------------------------------------------
-- Salidas (se insertan antes que los ejemplares que las referencian)
-- ---------------------------------------------------------------------
INSERT INTO salida
  (consecutivo_salida, motivo, observaciones, fecha,
   cliente_tipo_documento, cliente_numero_documento,
   empleado_tipo_documento, empleado_numero_documento) VALUES
  (1, 'VENTA', 'Venta por reserva',        '2026-10-15', 'CC', '80123456',   'CC', '1020202020'),
  (2, 'VENTA', 'Venta directa en tienda',  '2026-10-20', 'CC', '1030303030', 'CC', '1020202020');

-- ---------------------------------------------------------------------
-- Ejemplares físicos
-- ---------------------------------------------------------------------
INSERT INTO ejemplar
  (id_ejemplar, ubicacion, estado, precio_sugerido, fecha_ingreso, codigo_etiqueta, observaciones_danos,
   impresion_carta_id_carta, impresion_numero_impresion, condicion_codigo_condicion, salida_consecutivo_salida) VALUES
  (1,  'Vitrina A-1', 'DISPONIBLE', 450000.00, '2026-09-01', 'MC-0001', NULL,                          1, 1, 'NM', NULL),
  (2,  'Vendido',     'VENDIDO',     12000.00, '2026-09-05', 'MC-0002', NULL,                          1, 2, 'NM', 1),
  (3,  'Reservado',   'RESERVADO',   85500.00, '2026-09-10', 'MC-0003', 'Leve marca en el borde',      3, 1, 'LP', NULL),
  (4,  'Reservado',   'RESERVADO',  100000.00, '2026-09-12', 'MC-0004', NULL,                          4, 1, 'MP', NULL),
  (5,  'Vendido',     'VENDIDO',     15000.00, '2026-09-15', 'MC-0005', NULL,                          2, 1, 'NM', 2),
  (6,  'Vitrina B-2', 'DISPONIBLE', 800000.00, '2026-09-20', 'MC-0006', NULL,                          5, 1, 'NM', NULL),
  (7,  'Caja C-3',    'DISPONIBLE', 105000.00, '2026-09-22', 'MC-0007', 'Esquinas desgastadas',        6, 1, 'HP', NULL),
  (8,  'Vitrina A-4', 'DISPONIBLE',  70000.00, '2026-10-01', 'MC-0008', NULL,                          7, 1, 'NM', NULL),
  (9,  'Vitrina A-2', 'DISPONIBLE',  20000.00, '2026-10-03', 'MC-0009', NULL,                          1, 3, 'NM', NULL),
  (10, 'Caja C-1',    'DISPONIBLE',  85500.00, '2026-10-05', 'MC-0010', NULL,                          3, 2, 'LP', NULL);

-- ---------------------------------------------------------------------
-- Reservas y su detalle
-- ---------------------------------------------------------------------
INSERT INTO reserva
  (consecutivo, fecha_creacion, estado, fecha_vencimiento,
   cliente_tipo_documento, cliente_numero_documento, salida_consecutivo_salida) VALUES
  (1, '2026-10-28', 'ACTIVA',     '2026-11-04', 'CC', '1030303030', NULL),
  (2, '2026-10-10', 'COMPLETADA', '2026-10-17', 'CC', '80123456',   1),
  (3, '2026-09-20', 'VENCIDA',    '2026-09-27', 'CE', '99887766',   NULL);

INSERT INTO ejemplar_reserva (id_ejemplar, consecutivo) VALUES
  (3, 1),
  (4, 1),
  (2, 2),
  (10, 3);