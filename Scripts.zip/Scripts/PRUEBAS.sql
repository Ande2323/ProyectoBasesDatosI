-- =====================================================================
-- Script 04: consultas de prueba (solo lectura)
-- =====================================================================
USE magic_cards;

-- 1. Cartas con su tipo
SELECT c.nombre_oficial, t.nombre AS tipo
FROM carta c
JOIN carta_tipo ct ON ct.carta_id_carta = c.id_carta
JOIN tipo t ON t.id_tipo = ct.tipo_id_tipo;

-- 2. Ejemplares con su carta y condicion
SELECT e.id_ejemplar, c.nombre_oficial, co.nombre AS condicion, e.estado, e.precio_sugerido
FROM ejemplar e
JOIN carta c ON c.id_carta = e.impresion_carta_id_carta
JOIN condicion co ON co.codigo_condicion = e.condicion_codigo_condicion;

-- 3. Reservas con su cliente
SELECT r.consecutivo, r.estado, cl.nombres, cl.apellidos
FROM reserva r
JOIN cliente cl ON cl.tipo_documento = r.cliente_tipo_documento
               AND cl.numero_documento = r.cliente_numero_documento;

-- 4. Impresiones con edicion, rareza e idioma
SELECT c.nombre_oficial, ed.nombre AS edicion, r.nombre AS rareza, i.nombre AS idioma
FROM impresion im
JOIN carta c ON c.id_carta = im.carta_id_carta
JOIN edicion ed ON ed.id_edicion = im.edicion_id_edicion
JOIN rareza r ON r.id_rareza = im.rareza_id_rareza
JOIN idioma i ON i.id_idioma = im.idioma_id_idioma;