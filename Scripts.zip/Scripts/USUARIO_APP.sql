-- =====================================================================
-- Script 03: usuario de la aplicacion (back en Windows -> MySQL en la VM)
-- Ejecutar despues de 01_ddl.sql y 02_dml.sql
-- '%' permite conectarse desde cualquier equipo de la red.
-- Si quiere restringirlo, cambie '%' por la IP de su Windows (ej. '192.168.1.10').
-- Cambie la clave antes de la entrega final.
-- =====================================================================

-- Borra versiones anteriores del usuario (si existieran) para evitar conflictos.
DROP USER IF EXISTS 'app_web'@'localhost';
DROP USER IF EXISTS 'app_web'@'%';
CREATE USER 'app_web'@'%' IDENTIFIED BY 'AppWeb123*';
GRANT SELECT, INSERT, UPDATE, DELETE ON magic_cards.* TO 'app_web'@'%';
FLUSH PRIVILEGES;