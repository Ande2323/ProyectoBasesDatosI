-- =====================================================================
-- Proyecto Final - Bases de Datos 1 - Universidad El Bosque
-- Script 01: DDL (creación de objetos) - MySQL 8.x
-- Basado en el Modelo Relacional (Data Modeler) de Magic_Cards
-- =====================================================================

-- ATENCION: borra la base si ya existe, para poder re-ejecutar el script limpio.
DROP DATABASE IF EXISTS magic_cards;

CREATE DATABASE magic_cards
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE magic_cards;

-- ---------------------------------------------------------------------
-- 1. Seguridad y personas
-- ---------------------------------------------------------------------
CREATE TABLE rol (
  codigo_rol  VARCHAR(10) NOT NULL,
  nombre      VARCHAR(50) NOT NULL,
  CONSTRAINT rol_PK PRIMARY KEY (codigo_rol)
) ENGINE=InnoDB;

CREATE TABLE cuenta_usuario (
  id_cuenta_u     INT          NOT NULL AUTO_INCREMENT,
  nombre_usuario  VARCHAR(50)  NOT NULL,
  contrasena      VARCHAR(255) NOT NULL,          -- almacenar HASH, nunca texto plano
  estado          VARCHAR(20),
  fecha_u_acceso  TIMESTAMP    NULL DEFAULT NULL,
  rol_codigo_rol  VARCHAR(10)  NOT NULL,
  CONSTRAINT cuenta_usuario_PK PRIMARY KEY (id_cuenta_u),
  CONSTRAINT cuenta_usuario_nombre_UN UNIQUE (nombre_usuario),
  CONSTRAINT cuenta_usuario_rol_FK FOREIGN KEY (rol_codigo_rol)
    REFERENCES rol (codigo_rol)
) ENGINE=InnoDB;

CREATE TABLE cliente (
  tipo_documento              VARCHAR(5)   NOT NULL,
  numero_documento            VARCHAR(20)  NOT NULL,
  nombres                     VARCHAR(100) NOT NULL,
  apellidos                   VARCHAR(100) NOT NULL,
  cuenta_usuario_id_cuenta_u  INT          NOT NULL,
  CONSTRAINT cliente_PK PRIMARY KEY (tipo_documento, numero_documento),
  CONSTRAINT cliente_cuenta_usuario_id_cuenta_u_UN UNIQUE (cuenta_usuario_id_cuenta_u),
  CONSTRAINT cliente_cuenta_usuario_FK FOREIGN KEY (cuenta_usuario_id_cuenta_u)
    REFERENCES cuenta_usuario (id_cuenta_u)
) ENGINE=InnoDB;

CREATE TABLE empleado (
  tipo_documento              VARCHAR(5)   NOT NULL,
  numero_documento            VARCHAR(20)  NOT NULL,
  nombres                     VARCHAR(100) NOT NULL,
  apellidos                   VARCHAR(100) NOT NULL,
  cargo                       VARCHAR(50),
  estado                      VARCHAR(20),
  fecha_vinculacion           DATE         NOT NULL,
  cuenta_usuario_id_cuenta_u  INT          NOT NULL,
  CONSTRAINT empleado_PK PRIMARY KEY (tipo_documento, numero_documento),
  CONSTRAINT empleado_cuenta_usuario_id_cuenta_u_UN UNIQUE (cuenta_usuario_id_cuenta_u),
  CONSTRAINT empleado_cuenta_usuario_FK FOREIGN KEY (cuenta_usuario_id_cuenta_u)
    REFERENCES cuenta_usuario (id_cuenta_u)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. Catálogos
-- ---------------------------------------------------------------------
CREATE TABLE idioma (
  id_idioma  INT         NOT NULL AUTO_INCREMENT,
  nombre     VARCHAR(50) NOT NULL,
  codigo     VARCHAR(10) NOT NULL,
  CONSTRAINT idioma_PK PRIMARY KEY (id_idioma)
) ENGINE=InnoDB;

CREATE TABLE rareza (
  id_rareza  INT         NOT NULL AUTO_INCREMENT,
  nombre     VARCHAR(30) NOT NULL,
  codigo     VARCHAR(5)  NOT NULL,
  CONSTRAINT rareza_PK PRIMARY KEY (id_rareza)
) ENGINE=InnoDB;

CREATE TABLE artista (
  id_artista  INT          NOT NULL AUTO_INCREMENT,
  nombre      VARCHAR(100) NOT NULL,
  CONSTRAINT artista_PK PRIMARY KEY (id_artista)
) ENGINE=InnoDB;

CREATE TABLE edicion (
  id_edicion         INT          NOT NULL AUTO_INCREMENT,
  nombre             VARCHAR(100) NOT NULL,
  codigo_impreso     VARCHAR(10)  NOT NULL,
  fecha_lanzamiento  DATE,
  tipo_edicion       VARCHAR(30),
  cantidad_cartas    SMALLINT,
  CONSTRAINT edicion_PK PRIMARY KEY (id_edicion)
) ENGINE=InnoDB;

CREATE TABLE condicion (
  codigo_condicion  VARCHAR(5)   NOT NULL,
  nombre            VARCHAR(50)  NOT NULL,
  factor_ajuste     DECIMAL(4,3) NOT NULL,
  CONSTRAINT condicion_PK PRIMARY KEY (codigo_condicion)
) ENGINE=InnoDB;

CREATE TABLE color (
  id_color        INT         NOT NULL AUTO_INCREMENT,
  nombre_color    VARCHAR(30) NOT NULL,
  orden_canonico  TINYINT,
  CONSTRAINT color_PK PRIMARY KEY (id_color)
) ENGINE=InnoDB;

CREATE TABLE tipo (
  id_tipo  INT         NOT NULL AUTO_INCREMENT,
  nivel    TINYINT,
  codigo   VARCHAR(10) NOT NULL,
  nombre   VARCHAR(50) NOT NULL,
  CONSTRAINT tipo_PK PRIMARY KEY (id_tipo)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. Carta y sus relaciones N:M
-- ---------------------------------------------------------------------
CREATE TABLE carta (
  id_carta        INT           NOT NULL AUTO_INCREMENT,
  nombre_oficial  VARCHAR(200)  NOT NULL,
  texto_oraculo   VARCHAR(2000),
  coste_mana      VARCHAR(30),
  poder           VARCHAR(5),
  lealtad         VARCHAR(5),
  resistencia     VARCHAR(5),
  CONSTRAINT carta_PK PRIMARY KEY (id_carta)
) ENGINE=InnoDB;

CREATE TABLE carta_color (
  carta_id_carta  INT NOT NULL,
  color_id_color  INT NOT NULL,
  CONSTRAINT poseer_PK PRIMARY KEY (carta_id_carta, color_id_color),
  CONSTRAINT poseer_carta_FK FOREIGN KEY (carta_id_carta)
    REFERENCES carta (id_carta) ON DELETE CASCADE,
  CONSTRAINT poseer_color_FK FOREIGN KEY (color_id_color)
    REFERENCES color (id_color) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE carta_tipo (
  carta_id_carta  INT NOT NULL,
  tipo_id_tipo    INT NOT NULL,
  CONSTRAINT pertenecer_PK PRIMARY KEY (carta_id_carta, tipo_id_tipo),
  CONSTRAINT pertenecer_carta_FK FOREIGN KEY (carta_id_carta)
    REFERENCES carta (id_carta) ON DELETE CASCADE,
  CONSTRAINT pertenecer_tipo_FK FOREIGN KEY (tipo_id_tipo)
    REFERENCES tipo (id_tipo) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. Impresión (PK compuesta + relación recursiva) y precios
-- ---------------------------------------------------------------------
CREATE TABLE impresion (
  carta_id_carta              INT      NOT NULL,
  numero_impresion            SMALLINT NOT NULL,
  numero_coleccion            VARCHAR(10),
  indicador_foil              CHAR(1)  NOT NULL,
  rareza_id_rareza            INT      NOT NULL,
  idioma_id_idioma            INT      NOT NULL,
  artista_id_artista          INT      NOT NULL,
  edicion_id_edicion          INT      NOT NULL,
  impresion_carta_id_carta    INT      NULL,   -- FK recursiva (impresión de referencia)
  impresion_numero_impresion  SMALLINT NULL,
  CONSTRAINT impresion_PK PRIMARY KEY (carta_id_carta, numero_impresion),
  CONSTRAINT impresion_carta_FK FOREIGN KEY (carta_id_carta)
    REFERENCES carta (id_carta),
  CONSTRAINT impresion_rareza_FK FOREIGN KEY (rareza_id_rareza)
    REFERENCES rareza (id_rareza),
  CONSTRAINT impresion_idioma_FK FOREIGN KEY (idioma_id_idioma)
    REFERENCES idioma (id_idioma),
  CONSTRAINT impresion_artista_FK FOREIGN KEY (artista_id_artista)
    REFERENCES artista (id_artista),
  CONSTRAINT impresion_edicion_FK FOREIGN KEY (edicion_id_edicion)
    REFERENCES edicion (id_edicion),
  CONSTRAINT impresion_impresion_FK FOREIGN KEY (impresion_carta_id_carta, impresion_numero_impresion)
    REFERENCES impresion (carta_id_carta, numero_impresion)
) ENGINE=InnoDB;

CREATE TABLE precio_referencia (
  impresion_carta_id_carta    INT           NOT NULL,
  impresion_numero_impresion  SMALLINT      NOT NULL,
  fecha                       DATE          NOT NULL,
  valor                       DECIMAL(12,2) NOT NULL,
  fuente_cotizacion           VARCHAR(100),
  CONSTRAINT precio_referencia_PK PRIMARY KEY
    (impresion_carta_id_carta, impresion_numero_impresion, fecha),
  CONSTRAINT precio_referencia_impresion_FK
    FOREIGN KEY (impresion_carta_id_carta, impresion_numero_impresion)
    REFERENCES impresion (carta_id_carta, numero_impresion)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. Operación: salida, ejemplar, reserva
-- ---------------------------------------------------------------------
CREATE TABLE salida (
  consecutivo_salida        INT          NOT NULL AUTO_INCREMENT,
  motivo                    VARCHAR(50),
  observaciones             VARCHAR(500),
  fecha                     DATE         NOT NULL,
  cliente_tipo_documento    VARCHAR(5)   NOT NULL,
  cliente_numero_documento  VARCHAR(20)  NOT NULL,
  empleado_tipo_documento   VARCHAR(5)   NOT NULL,
  empleado_numero_documento VARCHAR(20)  NOT NULL,
  CONSTRAINT salida_PK PRIMARY KEY (consecutivo_salida),
  CONSTRAINT salida_cliente_FK FOREIGN KEY (cliente_tipo_documento, cliente_numero_documento)
    REFERENCES cliente (tipo_documento, numero_documento),
  CONSTRAINT salida_empleado_FK FOREIGN KEY (empleado_tipo_documento, empleado_numero_documento)
    REFERENCES empleado (tipo_documento, numero_documento)
) ENGINE=InnoDB;

CREATE TABLE ejemplar (
  id_ejemplar                 INT           NOT NULL AUTO_INCREMENT,
  ubicacion                   VARCHAR(50),
  estado                      VARCHAR(20),
  precio_sugerido             DECIMAL(12,2),
  fecha_ingreso               DATE          NOT NULL,
  codigo_etiqueta             VARCHAR(30),
  observaciones_danos         VARCHAR(500),
  impresion_carta_id_carta    INT           NOT NULL,
  impresion_numero_impresion  SMALLINT      NOT NULL,
  condicion_codigo_condicion  VARCHAR(5)    NOT NULL,
  salida_consecutivo_salida   INT           NULL,
  CONSTRAINT ejemplar_PK PRIMARY KEY (id_ejemplar),
  CONSTRAINT ejemplar_condicion_FK FOREIGN KEY (condicion_codigo_condicion)
    REFERENCES condicion (codigo_condicion),
  CONSTRAINT ejemplar_impresion_FK FOREIGN KEY (impresion_carta_id_carta, impresion_numero_impresion)
    REFERENCES impresion (carta_id_carta, numero_impresion),
  CONSTRAINT ejemplar_salida_FK FOREIGN KEY (salida_consecutivo_salida)
    REFERENCES salida (consecutivo_salida)
) ENGINE=InnoDB;

CREATE TABLE reserva (
  consecutivo                INT         NOT NULL AUTO_INCREMENT,
  fecha_creacion             DATE        NOT NULL,
  estado                     VARCHAR(20),
  fecha_vencimiento          DATE,
  cliente_tipo_documento     VARCHAR(5)  NOT NULL,
  cliente_numero_documento   VARCHAR(20) NOT NULL,
  salida_consecutivo_salida  INT         NULL,
  CONSTRAINT reserva_PK PRIMARY KEY (consecutivo),
  CONSTRAINT reserva_salida_consecutivo_salida_UN UNIQUE (salida_consecutivo_salida),
  CONSTRAINT reserva_salida_FK FOREIGN KEY (salida_consecutivo_salida)
    REFERENCES salida (consecutivo_salida),
  CONSTRAINT reserva_cliente_FK FOREIGN KEY (cliente_tipo_documento, cliente_numero_documento)
    REFERENCES cliente (tipo_documento, numero_documento)
) ENGINE=InnoDB;

CREATE TABLE ejemplar_reserva (
  id_ejemplar  INT NOT NULL,
  consecutivo  INT NOT NULL,
  CONSTRAINT pk_ejemplar_reserva PRIMARY KEY (id_ejemplar, consecutivo),
  CONSTRAINT apartar_ejemplar FOREIGN KEY (id_ejemplar)
    REFERENCES ejemplar (id_ejemplar),
  CONSTRAINT apartar_reserva FOREIGN KEY (consecutivo)
    REFERENCES reserva (consecutivo)
) ENGINE=InnoDB;

CREATE TABLE imagen_ejemplar (
  id_ejemplar  INT        NOT NULL,
  contenido    MEDIUMBLOB NOT NULL,
  CONSTRAINT imagen_ejemplar_PK PRIMARY KEY (id_ejemplar),
  CONSTRAINT imagen_ejemplar_ejemplar_FK FOREIGN KEY (id_ejemplar)
    REFERENCES ejemplar (id_ejemplar) ON DELETE CASCADE
) ENGINE=InnoDB;
